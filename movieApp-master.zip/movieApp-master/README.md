https://mirgradr.github.io/movieApp/dest/index.html
movieApp
Working with API of Movie DB. Gulp, SASS/SCSS. 
